<script setup>
import { ref } from 'vue'
import logo from '@/assets/logo.png'

const activeLink = ref('Home')
const open = ref(false)

const menus = [
  { name: 'Home', href: '/' },
  { name: 'About', href: '/about' },
  { name: 'Product', href: '/product' },
  { name: 'Contact', href: '/contact' },
  { name: 'Keranjang', href: '/keranjang' }
]

function setActive(menu) {
  activeLink.value = menu
  open.value = false // tutup menu mobile setelah klik
}
</script>

<template>
  <nav class="bg-[#FADADD] shadow-md border-b border-[#FFF4E6] fixed w-full top-0 z-50">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <div class="flex justify-between h-16 items-center">
        <!-- LOGO -->
        <div class="flex items-center">
          <img :src="logo" alt="Sweetify Logo" class="h-20 w-20 mr-2" />
          <span class="font-semibold text-[#B58E64] text-xl tracking-wide">
            Sweetify
          </span>
        </div>

        <!-- NAVIGATION LINKS -->
        <div class="hidden sm:flex space-x-6">
          <router-link
            v-for="menu in menus"
            :key="menu.name"
            :to="menu.href"
            @click="setActive(menu.name)"
            class="px-4 py-2 rounded-md text-sm font-medium transition-all duration-200"
            :class="activeLink === menu.name
              ? 'bg-[#B58E64] text-white'
              : 'text-[#6b4f2b] hover:bg-[#FFF4E6] hover:text-[#B58E64]'"
          >
            {{ menu.name }}
          </router-link>
        </div>

        <!-- MOBILE MENU BUTTON -->
        <div class="sm:hidden flex items-center">
          <button
            type="button"
            @click="open = !open"
            class="inline-flex items-center justify-center rounded-md p-2 text-[#B58E64] hover:bg-[#FFF4E6]"
          >
            <svg
              class="block h-6 w-6"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              aria-hidden="true"
            >
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      </div>
    </div>

    <!-- MOBILE MENU -->
    <div class="sm:hidden" v-if="open">
      <div class="px-2 pt-2 pb-3 space-y-1 bg-[#FFF4E6]">
        <router-link
          v-for="menu in menus"
          :key="menu.name"
          :to="menu.href"
          @click="setActive(menu.name)"
          class="block w-full text-left px-3 py-2 rounded-md text-base font-medium transition-all duration-200"
          :class="activeLink === menu.name
            ? 'bg-[#B58E64] text-white'
            : 'text-[#6b4f2b] hover:bg-[#FADADD] hover:text-[#B58E64]'"
        >
          {{ menu.name }}
        </router-link>
      </div>
    </div>
  </nav>
</template>

<style scoped>
nav {
  font-family: 'Poppins', sans-serif;
}
</style>
