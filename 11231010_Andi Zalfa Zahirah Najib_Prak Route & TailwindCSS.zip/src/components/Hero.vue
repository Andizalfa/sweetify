<script setup>
import { useRouter } from 'vue-router'
import heroImage from '@/assets/cake5.jpg'

// Inisialisasi router agar bisa berpindah halaman
const router = useRouter()

// Fungsi navigasi ke halaman produk
const goToProduk = () => {
  router.push('/produk')
}
</script>

<template>
  <section class="relative flex items-center justify-start h-[90vh] text-white">
    <!-- Gambar latar sebagai <img> agar mudah dikendalikan dengan object-cover -->
    <img :src="heroImage" alt="Hero background" class="absolute inset-0 w-full h-full object-cover object-center z-0" />

    <!-- Overlay gelap agar teks lebih jelas -->
    <div class="absolute inset-0 bg-black/50 z-10"></div>

    <!-- Konten teks -->
    <div class="relative z-20 max-w-3xl pl-8 sm:pl-16 text-left">
      <h3 class="text-lg sm:text-2xl font-semibold text-[#FFF4E6] mb-1">Welcome!</h3>

        <h1 class="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-extrabold text-[#FFF4E6] leading-tight drop-shadow-lg">
        Experience The Deliciousness <br />
        <span class="text-[#FFF4E6]">Of Special Cakes!</span>
      </h1>

      <p class="text-[#FFF4E6] mt-4 text-base sm:text-lg max-w-xl leading-relaxed">
        Temukan cita rasa istimewa dari kue manis yang dibuat dengan cinta. 
        Setiap gigitan menghadirkan kebahagiaan di setiap momen spesial Anda.
      </p>

      <!-- Tombol Order Now -->
      <button
        @click="goToProduk"
        class="mt-6 bg-[#FADADD] text-[#B58E64] font-semibold px-8 py-3 rounded-full shadow-md 
               transition-all duration-300 hover:bg-[#B58E64] hover:text-white active:scale-95 focus:outline-none"
      >
        Order Now
      </button>
    </div>
  </section>
</template>

<style scoped>
section {
  font-family: 'Poppins', sans-serif;
}
</style>
