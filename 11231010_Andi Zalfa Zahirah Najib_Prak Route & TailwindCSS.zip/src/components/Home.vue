<script setup>
import Navbar from '@/components/Navbar.vue'
import Hero from '@/components/Hero.vue'
import Overview from '@/components/Overview.vue'
import Footer from '@/components/Footer.vue'
</script>

<template>
  <div>
    <Navbar />
    <Hero />
    <Overview />
    <Footer />
  </div>
</template>
